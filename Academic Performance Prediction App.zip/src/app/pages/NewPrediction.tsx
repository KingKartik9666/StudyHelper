import { useState } from "react";
import { useForm } from "react-hook-form";
import { BrainCircuit, Loader2, ArrowRight, RefreshCcw, Activity } from "lucide-react";

type PredictionFormData = {
  hoursStudied: number;
  attendance: number;
  parentalInvolvement: string;
  accessToResources: string;
  extracurricularActivities: string;
  sleepHours: number;
  previousScores: number;
  motivationLevel: string;
  internetAccess: string;
  tutoringSessions: number;
  familyIncome: string;
  teacherQuality: string;
  schoolType: string;
  peerInfluence: string;
  physicalActivity: number;
  learningDisabilities: string;
  parentalEducationLevel: string;
  distanceFromHome: string;
  gender: string;
};

export function NewPrediction() {
  const { register, handleSubmit, formState: { errors } } = useForm<PredictionFormData>({
    defaultValues: {
      hoursStudied: 15,
      attendance: 85,
      parentalInvolvement: "Medium",
      accessToResources: "Medium",
      extracurricularActivities: "No",
      sleepHours: 7,
      previousScores: 75,
      motivationLevel: "Medium",
      internetAccess: "Yes",
      tutoringSessions: 1,
      familyIncome: "Medium",
      teacherQuality: "Medium",
      schoolType: "Public",
      peerInfluence: "Neutral",
      physicalActivity: 3,
      learningDisabilities: "No",
      parentalEducationLevel: "College",
      distanceFromHome: "Moderate",
      gender: "Female"
    }
  });

  const [isPredicting, setIsPredicting] = useState(false);
  const [predictionResult, setPredictionResult] = useState<{
    score: number;
    risk: "Low" | "Medium" | "High";
    confidence: number;
    keyFactors: string[];
  } | null>(null);

  const onSubmit = (data: PredictionFormData) => {
    setIsPredicting(true);
    setPredictionResult(null);

    // Simulate API delay
    setTimeout(() => {
      // Mock prediction formula
      let baseScore = Number(data.previousScores) * 0.6 + Number(data.attendance) * 0.2 + Number(data.hoursStudied) * 0.5;
      
      if (data.parentalInvolvement === "High") baseScore += 5;
      if (data.motivationLevel === "High") baseScore += 5;
      if (data.learningDisabilities === "Yes") baseScore -= 5;
      if (data.peerInfluence === "Negative") baseScore -= 3;
      
      // Cap score at 100
      let finalScore = Math.min(Math.max(Math.round(baseScore), 40), 100);
      
      let risk: "Low" | "Medium" | "High" = "Low";
      if (finalScore < 60) risk = "High";
      else if (finalScore < 75) risk = "Medium";

      const keyFactors = [];
      if (data.attendance < 80) keyFactors.push("Low attendance rate");
      if (data.hoursStudied < 10) keyFactors.push("Low study hours");
      if (data.previousScores < 65) keyFactors.push("Historical performance concerns");
      if (data.motivationLevel === "Low") keyFactors.push("Low reported motivation");
      if (keyFactors.length === 0) keyFactors.push("Consistent positive performance metrics");

      setPredictionResult({
        score: finalScore,
        risk,
        confidence: Math.floor(Math.random() * (98 - 85 + 1) + 85), // Random between 85 and 98
        keyFactors
      });
      setIsPredicting(false);
    }, 2000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">Run Prediction</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Input student factors to generate an AI performance forecast</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Form Column */}
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm overflow-hidden">
          <div className="p-6 border-b border-gray-100 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-900/50">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              <Activity size={18} className="text-indigo-600 dark:text-indigo-400" />
              Student Profile Data
            </h2>
          </div>
          
          <form onSubmit={handleSubmit(onSubmit)} className="p-6">
            <div className="space-y-8">
              {/* Academic History */}
              <section>
                <h3 className="text-sm font-semibold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2 mb-4">Academic & Engagement</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Previous Scores (0-100)</label>
                    <input type="number" {...register("previousScores", { required: true, min: 0, max: 100 })} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Attendance %</label>
                    <input type="number" {...register("attendance", { required: true, min: 0, max: 100 })} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Hours Studied (Weekly)</label>
                    <input type="number" {...register("hoursStudied", { required: true, min: 0 })} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Tutoring Sessions</label>
                    <input type="number" {...register("tutoringSessions", { required: true, min: 0 })} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Motivation Level</label>
                    <select {...register("motivationLevel")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Learning Disabilities</label>
                    <select {...register("learningDisabilities")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="No">No</option>
                      <option value="Yes">Yes</option>
                    </select>
                  </div>
                </div>
              </section>

              {/* Environment & Support */}
              <section>
                <h3 className="text-sm font-semibold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2 mb-4">Environment & Support</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Parental Involvement</label>
                    <select {...register("parentalInvolvement")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Access to Resources</label>
                    <select {...register("accessToResources")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Family Income</label>
                    <select {...register("familyIncome")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Parental Education</label>
                    <select {...register("parentalEducationLevel")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="High School">High School</option>
                      <option value="College">College</option>
                      <option value="Postgraduate">Postgraduate</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Internet Access</label>
                    <select {...register("internetAccess")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </div>
                </div>
              </section>

              {/* Lifestyle & Demographics */}
              <section>
                <h3 className="text-sm font-semibold text-gray-900 dark:text-white border-b border-gray-200 dark:border-gray-700 pb-2 mb-4">Lifestyle & Demographics</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Sleep Hours</label>
                    <input type="number" {...register("sleepHours", { required: true, min: 0, max: 24 })} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Physical Activity</label>
                    <input type="number" {...register("physicalActivity", { required: true, min: 0 })} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Extracurriculars</label>
                    <select {...register("extracurricularActivities")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Yes">Yes</option>
                      <option value="No">No</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Peer Influence</label>
                    <select {...register("peerInfluence")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Positive">Positive</option>
                      <option value="Neutral">Neutral</option>
                      <option value="Negative">Negative</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">School Type</label>
                    <select {...register("schoolType")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Public">Public</option>
                      <option value="Private">Private</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Teacher Quality</label>
                    <select {...register("teacherQuality")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Low">Low</option>
                      <option value="Medium">Medium</option>
                      <option value="High">High</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Distance from Home</label>
                    <select {...register("distanceFromHome")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Near">Near</option>
                      <option value="Moderate">Moderate</option>
                      <option value="Far">Far</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">Gender</label>
                    <select {...register("gender")} className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>
                </div>
              </section>
            </div>

            <div className="mt-8 flex justify-end">
              <button 
                type="submit" 
                disabled={isPredicting}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2.5 rounded-lg text-sm font-medium shadow-sm transition-colors flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isPredicting ? (
                  <><Loader2 size={18} className="animate-spin" /> Analyzing Data...</>
                ) : (
                  <><BrainCircuit size={18} /> Generate Prediction</>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Results Column */}
        <div className="lg:col-span-1">
          <div className="sticky top-6">
            {!predictionResult && !isPredicting && (
              <div className="bg-gray-50 dark:bg-gray-800/50 border border-gray-200 dark:border-gray-700 rounded-xl p-8 text-center flex flex-col items-center justify-center h-full min-h-[300px]">
                <BrainCircuit size={48} className="text-gray-300 dark:text-gray-600 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">Ready to Predict</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">Fill out the student factors and run the model to see the predicted exam score and risk assessment.</p>
              </div>
            )}

            {isPredicting && (
              <div className="bg-indigo-50 dark:bg-indigo-900/20 border border-indigo-100 dark:border-indigo-800 rounded-xl p-8 text-center flex flex-col items-center justify-center min-h-[300px]">
                <Loader2 size={48} className="text-indigo-600 dark:text-indigo-400 mb-4 animate-spin" />
                <h3 className="text-lg font-medium text-indigo-900 dark:text-indigo-100 mb-2">Processing Data</h3>
                <p className="text-sm text-indigo-700/70 dark:text-indigo-300/70">Feeding variables into the predictive model...</p>
              </div>
            )}

            {predictionResult && !isPredicting && (
              <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg overflow-hidden animate-in fade-in zoom-in duration-300">
                <div className="bg-indigo-600 dark:bg-indigo-700 p-6 text-white text-center">
                  <p className="text-indigo-200 text-sm font-medium uppercase tracking-wider mb-1">Predicted Exam Score</p>
                  <div className="text-6xl font-bold tracking-tight">{predictionResult.score}</div>
                  <p className="text-indigo-200 text-xs mt-2 flex items-center justify-center gap-1">
                    Model Confidence: {predictionResult.confidence}%
                  </p>
                </div>
                
                <div className="p-6 space-y-6">
                  <div>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Assessed Risk Level</p>
                    <div className="flex items-center gap-2">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-bold border
                        ${predictionResult.risk === 'High' ? 'bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-400 border-red-200 dark:border-red-800' :
                          predictionResult.risk === 'Medium' ? 'bg-yellow-50 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-400 border-yellow-200 dark:border-yellow-800' :
                          'bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800'
                        }
                      `}>
                        {predictionResult.risk} Risk
                      </span>
                    </div>
                  </div>

                  <div className="border-t border-gray-100 dark:border-gray-700 pt-4">
                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-3 font-medium">Key Influencing Factors</p>
                    <ul className="space-y-2">
                      {predictionResult.keyFactors.map((factor, i) => (
                        <li key={i} className="text-sm text-gray-700 dark:text-gray-300 flex items-start gap-2">
                          <ArrowRight size={16} className="text-indigo-400 dark:text-indigo-500 shrink-0 mt-0.5" />
                          {factor}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button 
                    onClick={() => setPredictionResult(null)}
                    className="w-full flex items-center justify-center gap-2 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                  >
                    <RefreshCcw size={16} /> Reset Form
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}