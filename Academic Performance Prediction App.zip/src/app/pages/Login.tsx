import { useNavigate } from "react-router";
import { BrainCircuit, GraduationCap, Users } from "lucide-react";
import { useState } from "react";

export function Login() {
  const navigate = useNavigate();
  const [isDarkMode] = useState(() => document.documentElement.classList.contains('dark'));

  const handleLogin = (role: 'teacher' | 'student') => {
    localStorage.setItem('userRole', role);
    if (role === 'teacher') {
      navigate('/');
    } else {
      // Direct student to their specific profile view
      navigate('/students/STU-001');
    }
  };

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center p-4 ${isDarkMode ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900'}`}>
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl -mr-48 -mt-48 pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl -ml-48 -mb-48 pointer-events-none"></div>

      <div className="flex items-center gap-3 mb-10 relative z-10">
        <div className="w-12 h-12 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30">
          <BrainCircuit size={28} />
        </div>
        <span className="font-bold text-3xl tracking-tight">StudyHelper</span>
      </div>

      <div className="w-full max-w-2xl bg-white dark:bg-gray-800 rounded-2xl shadow-xl border border-gray-200 dark:border-gray-700 p-8 relative z-10">
        <div className="text-center mb-10">
          <h1 className="text-2xl font-bold mb-2">Welcome back</h1>
          <p className="text-gray-500 dark:text-gray-400">Choose your role to continue to your dashboard</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <button 
            onClick={() => handleLogin('teacher')}
            className="group flex flex-col items-center justify-center p-8 bg-gray-50 dark:bg-gray-900/50 rounded-xl border-2 border-transparent hover:border-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/20 transition-all duration-300"
          >
            <div className="w-16 h-16 rounded-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:shadow-lg transition-all duration-300">
              <Users size={32} className="text-indigo-600 dark:text-indigo-400" />
            </div>
            <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Teacher / Admin</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              View class dashboards, predictive analytics, and run cohort models
            </p>
          </button>

          <button 
            onClick={() => handleLogin('student')}
            className="group flex flex-col items-center justify-center p-8 bg-gray-50 dark:bg-gray-900/50 rounded-xl border-2 border-transparent hover:border-emerald-500 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 transition-all duration-300"
          >
            <div className="w-16 h-16 rounded-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:shadow-lg transition-all duration-300">
              <GraduationCap size={32} className="text-emerald-600 dark:text-emerald-400" />
            </div>
            <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Student</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              View your personal performance, GPA predictions, and AI suggestions
            </p>
          </button>
        </div>
        
        <div className="mt-8 text-center text-xs text-gray-400 dark:text-gray-500">
          <p>By logging in, you agree to the StudyHelper Terms of Service and Privacy Policy.</p>
        </div>
      </div>
    </div>
  );
}