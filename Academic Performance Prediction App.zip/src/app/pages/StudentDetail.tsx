import { useParams, Link } from "react-router";
import { ArrowLeft, BrainCircuit, Activity, BookOpen, AlertCircle, TrendingUp, CheckCircle2, Lightbulb, ArrowRight } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend } from "recharts";
import { students } from "../data/mockData";

export function StudentDetail() {
  const { id } = useParams();
  const student = students.find(s => s.id === id) || students[0];
  const isStudent = localStorage.getItem('userRole') === 'student';

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {!isStudent && (
        <Link to="/students" className="inline-flex items-center text-sm font-medium text-gray-500 dark:text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors">
          <ArrowLeft size={16} className="mr-1.5" /> Back to Directory
        </Link>
      )}

      {/* Header Profile */}
      <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 dark:bg-indigo-900/20 rounded-full blur-3xl -mr-32 -mt-32 opacity-50 pointer-events-none"></div>
        
        <div className="flex items-center gap-5 relative z-10">
          <img src={student.avatar} alt={student.name} className="w-20 h-20 rounded-full object-cover border-4 border-white dark:border-gray-800 shadow-md" />
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">{student.name}</h1>
            <div className="flex items-center gap-3 text-sm text-gray-500 dark:text-gray-400 mt-1">
              <span>{student.id}</span>
              <span className="w-1 h-1 bg-gray-300 dark:bg-gray-600 rounded-full"></span>
              <span>{student.grade}</span>
              <span className="w-1 h-1 bg-gray-300 dark:bg-gray-600 rounded-full"></span>
              <span className="flex items-center gap-1"><CheckCircle2 size={14} className="text-emerald-500"/> {student.attendance}% Attendance</span>
            </div>
          </div>
        </div>

        <div className="flex gap-4 relative z-10 w-full sm:w-auto">
          <div className="bg-gray-50 dark:bg-gray-900/50 rounded-lg p-3 border border-gray-200 dark:border-gray-700 flex-1 sm:flex-none text-center min-w-[100px]">
            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide">Current GPA</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{student.currentGPA.toFixed(2)}</p>
          </div>
          <div className="bg-indigo-50 dark:bg-indigo-900/30 rounded-lg p-3 border border-indigo-100 dark:border-indigo-800 flex-1 sm:flex-none text-center min-w-[100px] shadow-sm">
            <p className="text-xs font-bold text-indigo-700 dark:text-indigo-400 uppercase tracking-wide flex items-center justify-center gap-1">
              <BrainCircuit size={12} /> Predicted
            </p>
            <p className="text-2xl font-bold text-indigo-700 dark:text-indigo-400 mt-1">{student.predictedGPA.toFixed(2)}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                <TrendingUp size={18} className="text-indigo-600 dark:text-indigo-400" />
                Performance Trajectory
              </h2>
              <span className="text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 px-2 py-1 rounded-md">Last updated: {student.lastUpdate}</span>
            </div>
            
            <div className="min-h-[300px]">
              <ResponsiveContainer width="100%" height="100%" minHeight={300}>
                <LineChart data={student.performanceHistory} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#374151" strokeOpacity={0.2} />
                  <XAxis dataKey="term" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dy={10} />
                  <YAxis domain={[2.0, 4.0]} axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} />
                  <RechartsTooltip 
                    contentStyle={{ borderRadius: '8px', border: '1px solid #374151', backgroundColor: '#1F2937', color: '#F3F4F6' }}
                  />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '20px' }} />
                  
                  {/* Visual split between historical and predicted */}
                  <Line 
                    type="monotone" 
                    dataKey="gpa" 
                    name="Historical GPA" 
                    stroke="#4B5563" 
                    strokeWidth={3}
                    dot={{ r: 4, fill: '#4B5563', strokeWidth: 2, stroke: '#fff' }}
                    activeDot={{ r: 6, fill: '#4B5563' }}
                    connectNulls
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-4 text-center">
              The model predicts a <span className="font-semibold text-gray-900 dark:text-white">{student.trend === 'up' ? 'positive' : student.trend === 'down' ? 'negative' : 'stable'} trend</span> for the upcoming quarter based on recent assignment scores, attendance patterns, and historical cohort data.
            </p>
          </div>

          {/* Key Factors Table */}
          {student.factors && (
            <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
                <Activity size={18} className="text-indigo-600 dark:text-indigo-400" />
                Student Performance Factors
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {Object.entries(student.factors).map(([key, value]) => (
                  <div key={key} className="border-b border-gray-100 dark:border-gray-700 pb-2">
                    <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</p>
                    <p className="text-sm font-semibold text-gray-900 dark:text-gray-100 mt-0.5">{value}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* AI Improvement Suggestions */}
          <div className="bg-indigo-50/50 dark:bg-indigo-900/10 border border-indigo-100 dark:border-indigo-800/50 rounded-xl p-6 shadow-sm">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
              <Lightbulb size={18} className="text-indigo-600 dark:text-indigo-400" />
              AI Actionable Suggestions
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
              Based on the predictive model, focusing on the following areas provides the highest probability of improving {student.name.split(' ')[0]}'s overall academic performance.
            </p>
            <div className="space-y-3">
              <div className="bg-white dark:bg-gray-800 border border-indigo-50 dark:border-gray-700 rounded-lg p-4 flex gap-3 shadow-sm transition-all hover:border-indigo-200 dark:hover:border-indigo-800">
                <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center shrink-0">
                  <span className="text-indigo-600 dark:text-indigo-400 font-bold text-sm">1</span>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Increase Tutoring Sessions</h3>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    The model indicates that increasing tutoring from 0 to 2 sessions per week has a high correlation with a +0.3 GPA bump for this student profile.
                  </p>
                  <button className="mt-2 text-xs font-medium text-indigo-600 dark:text-indigo-400 flex items-center gap-1 hover:underline">
                    Schedule session <ArrowRight size={12} />
                  </button>
                </div>
              </div>
              
              <div className="bg-white dark:bg-gray-800 border border-indigo-50 dark:border-gray-700 rounded-lg p-4 flex gap-3 shadow-sm transition-all hover:border-indigo-200 dark:hover:border-indigo-800">
                <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/50 flex items-center justify-center shrink-0">
                  <span className="text-indigo-600 dark:text-indigo-400 font-bold text-sm">2</span>
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-gray-900 dark:text-white">Focus on Math Completion</h3>
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    Missing assignments in Math are heavily dragging down the predicted trajectory. Establishing a daily homework check-in routine is recommended.
                  </p>
                  <button className="mt-2 text-xs font-medium text-indigo-600 dark:text-indigo-400 flex items-center gap-1 hover:underline">
                    View missing assignments <ArrowRight size={12} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="space-y-6">
          {/* Risk Card */}
          <div className={`border rounded-xl p-6 shadow-sm ${
            student.riskLevel === 'High' ? 'bg-red-50 dark:bg-red-900/10 border-red-200 dark:border-red-800' :
            student.riskLevel === 'Medium' ? 'bg-yellow-50 dark:bg-yellow-900/10 border-yellow-200 dark:border-yellow-800' :
            'bg-emerald-50 dark:bg-emerald-900/10 border-emerald-200 dark:border-emerald-800'
          }`}>
            <h3 className={`text-sm font-bold uppercase tracking-wide mb-2 flex items-center gap-2 ${
              student.riskLevel === 'High' ? 'text-red-800 dark:text-red-400' :
              student.riskLevel === 'Medium' ? 'text-yellow-800 dark:text-yellow-400' :
              'text-emerald-800 dark:text-emerald-400'
            }`}>
              <AlertCircle size={16} />
              AI Risk Assessment
            </h3>
            <p className={`text-3xl font-bold mb-4 ${
              student.riskLevel === 'High' ? 'text-red-700 dark:text-red-500' :
              student.riskLevel === 'Medium' ? 'text-yellow-700 dark:text-yellow-500' :
              'text-emerald-700 dark:text-emerald-500'
            }`}>
              {student.riskLevel} Risk
            </p>
            
            {student.riskLevel === 'High' && (
              <div className="bg-white/60 dark:bg-gray-900/50 p-3 rounded-lg border border-red-100/50 dark:border-red-800/50">
                <p className="text-sm text-red-900 dark:text-red-300 font-medium mb-1">Key Factors:</p>
                <ul className="text-xs text-red-800 dark:text-red-400 space-y-1 list-disc list-inside">
                  <li>Recent drop in Math scores (-15%)</li>
                  <li>3 missed assignments this week</li>
                  <li>Declining engagement score</li>
                </ul>
              </div>
            )}
            
            <button className={`w-full mt-4 py-2 px-4 rounded-lg text-sm font-semibold transition-colors ${
              student.riskLevel === 'High' ? 'bg-red-600 hover:bg-red-700 text-white shadow-sm' :
              student.riskLevel === 'Medium' ? 'bg-yellow-600 hover:bg-yellow-700 text-white shadow-sm' :
              'bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm'
            }`}>
              Create Intervention Plan
            </button>
          </div>

          {/* Subject Radar */}
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm">
            <h2 className="text-sm font-semibold text-gray-900 dark:text-white flex items-center gap-2 mb-4">
              <BookOpen size={16} className="text-indigo-600 dark:text-indigo-400" />
              Subject Breakdown
            </h2>
            <div className="w-full -ml-4 min-h-[200px]">
              <ResponsiveContainer width="100%" height="100%" minHeight={200}>
                <RadarChart cx="50%" cy="50%" outerRadius="70%" data={student.subjects}>
                  <PolarGrid stroke="#374151" strokeOpacity={0.5} />
                  <PolarAngleAxis dataKey="name" tick={{ fill: '#6B7280', fontSize: 10, fontWeight: 500 }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar name="Current" dataKey="current" stroke="#9CA3AF" fill="#9CA3AF" fillOpacity={0.3} />
                  <Radar name="Predicted" dataKey="predicted" stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.3} />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-4 space-y-2">
              {student.subjects.map(sub => (
                <div key={sub.name} className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">{sub.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="font-medium text-gray-900 dark:text-gray-100 w-8 text-right">{sub.current}</span>
                    <span className="text-gray-300 dark:text-gray-600">→</span>
                    <span className={`font-bold w-8 text-right ${sub.predicted < sub.current ? 'text-red-600 dark:text-red-400' : 'text-indigo-600 dark:text-indigo-400'}`}>
                      {sub.predicted}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}