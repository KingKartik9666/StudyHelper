import { ArrowUpRight, ArrowDownRight, AlertTriangle, TrendingUp, Users, BrainCircuit } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Legend } from "recharts";
import { Link } from "react-router";
import { globalMetrics, students, gpaTrendData } from "../data/mockData";

export function Dashboard() {
  const atRiskStudents = students.filter(s => s.riskLevel === "High");

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">AI Predictions Dashboard</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Real-time academic performance forecasts</p>
        </div>
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 border border-indigo-100 dark:border-indigo-800">
            <BrainCircuit size={16} />
            Model Accuracy: {globalMetrics.modelAccuracy}
          </span>
          <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-sm transition-colors">
            Generate Report
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Avg. Predicted GPA"
          value={globalMetrics.predictedAverageGPA}
          trend="+0.1"
          trendUp={true}
          icon={TrendingUp}
          color="indigo"
        />
        <MetricCard
          title="Current Avg. GPA"
          value={globalMetrics.averageGPA}
          trend="-0.05"
          trendUp={false}
          icon={TrendingUp}
          color="gray"
        />
        <MetricCard
          title="High Risk Students"
          value={globalMetrics.highRiskStudents}
          trend="+2 this week"
          trendUp={false}
          icon={AlertTriangle}
          color="red"
        />
        <MetricCard
          title="Active Interventions"
          value={globalMetrics.activeAlerts}
          trend="8 resolved"
          trendUp={true}
          icon={Users}
          color="emerald"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">District GPA Forecast</h2>
            <select className="text-sm bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-200 rounded-md focus:ring-indigo-500 focus:border-indigo-500 py-1 pl-2 pr-8 outline-none">
              <option>Last 6 Months</option>
              <option>Year to Date</option>
            </select>
          </div>
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%" minHeight={300}>
              <AreaChart data={gpaTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorActual" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#9CA3AF" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#9CA3AF" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorPred" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#4F46E5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#374151" strokeOpacity={0.1} />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} domain={[2.5, 4.0]} />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: '1px solid #374151', backgroundColor: '#1F2937', color: '#F3F4F6' }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
                <Area type="monotone" dataKey="actual" name="Actual GPA" stroke="#9CA3AF" fillOpacity={1} fill="url(#colorActual)" strokeWidth={2} />
                <Area type="monotone" dataKey="predicted" name="AI Predicted GPA" stroke="#4F46E5" strokeDasharray="5 5" fillOpacity={1} fill="url(#colorPred)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* High Risk Alerts */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
              <AlertTriangle className="text-red-500" size={20} />
              Critical Alerts
            </h2>
            <span className="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800 text-xs font-bold px-2 py-1 rounded-full">{atRiskStudents.length} New</span>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-3 -mx-2 px-2">
            {atRiskStudents.map(student => (
              <div key={student.id} className="p-3 border border-red-100 dark:border-red-900/50 bg-red-50/50 dark:bg-red-900/10 rounded-lg flex gap-3 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors">
                <img src={student.avatar} alt="" className="w-10 h-10 rounded-full object-cover shrink-0 border border-red-200 dark:border-red-800" />
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{student.name}</p>
                    <span className="text-xs font-semibold text-red-600 dark:text-red-400 flex items-center">
                      <ArrowDownRight size={12} className="mr-0.5" />
                      Pred: {student.predictedGPA.toFixed(1)}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{student.grade} • Current: {student.currentGPA.toFixed(1)}</p>
                  <Link to={`/students/${student.id}`} className="text-xs text-indigo-600 dark:text-indigo-400 font-medium mt-1 inline-block hover:underline">
                    View Intervention Plan →
                  </Link>
                </div>
              </div>
            ))}
            
            {/* Mock remaining alerts */}
            <div className="p-3 border border-yellow-100 dark:border-yellow-900/50 bg-yellow-50/50 dark:bg-yellow-900/10 rounded-lg flex gap-3">
              <div className="w-10 h-10 rounded-full bg-yellow-200 dark:bg-yellow-900/50 flex items-center justify-center shrink-0 border border-yellow-300 dark:border-yellow-700">
                <span className="text-yellow-700 dark:text-yellow-400 font-bold text-sm">MS</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">Math Scores Dropping</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">10th Grade Cohort • -12% avg</p>
              </div>
            </div>
          </div>
          <button className="w-full mt-4 py-2 border border-gray-200 dark:border-gray-700 rounded-lg text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
            View All Alerts
          </button>
        </div>
      </div>
    </div>
  );
}

function MetricCard({ title, value, trend, trendUp, icon: Icon, color }: any) {
  const colorMap: Record<string, string> = {
    indigo: "text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-900/20",
    emerald: "text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20",
    red: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-900/20",
    gray: "text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-800",
  };
  
  return (
    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500 dark:text-gray-400">{title}</p>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</h3>
        </div>
        <div className={`p-2 rounded-lg ${colorMap[color]}`}>
          <Icon size={20} />
        </div>
      </div>
      <div className="mt-4 flex items-center text-sm">
        {trendUp ? (
          <ArrowUpRight size={16} className="text-emerald-500 dark:text-emerald-400 mr-1" />
        ) : (
          <ArrowDownRight size={16} className={color === 'red' ? 'text-red-500 dark:text-red-400 mr-1' : 'text-gray-500 dark:text-gray-400 mr-1'} />
        )}
        <span className={trendUp ? "text-emerald-600 dark:text-emerald-400 font-medium" : (color === 'red' ? "text-red-600 dark:text-red-400 font-medium" : "text-gray-600 dark:text-gray-400 font-medium")}>
          {trend}
        </span>
        <span className="text-gray-400 dark:text-gray-500 ml-1">vs last term</span>
      </div>
    </div>
  );
}