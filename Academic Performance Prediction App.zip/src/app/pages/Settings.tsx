import { Save, Bell, Shield, Database, User, Key } from "lucide-react";
import { useState } from "react";

export function Settings() {
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved">("idle");

  const handleSave = () => {
    setSaveStatus("saving");
    setTimeout(() => {
      setSaveStatus("saved");
      setTimeout(() => setSaveStatus("idle"), 3000);
    }, 800);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-10">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">Settings</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Manage your account preferences and application settings</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1 space-y-1">
          <nav className="flex flex-col space-y-1">
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 bg-indigo-50 dark:bg-indigo-900/30 text-indigo-700 dark:text-indigo-400 rounded-lg text-sm font-medium">
              <User size={18} /> Profile
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-sm font-medium transition-colors">
              <Bell size={18} /> Notifications
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-sm font-medium transition-colors">
              <Shield size={18} /> Privacy & Security
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-sm font-medium transition-colors">
              <Database size={18} /> Data Management
            </a>
            <a href="#" className="flex items-center gap-3 px-3 py-2.5 text-gray-700 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-sm font-medium transition-colors">
              <Key size={18} /> API Keys
            </a>
          </nav>
        </div>

        <div className="md:col-span-3 space-y-6">
          {/* Profile Settings */}
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Profile Information</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Update your account details and public profile.</p>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="flex items-center gap-6">
                <img 
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100&h=100" 
                  alt="User avatar" 
                  className="w-20 h-20 rounded-full object-cover border border-gray-200 dark:border-gray-700"
                />
                <button className="px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-sm font-medium text-gray-700 dark:text-gray-200 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors shadow-sm">
                  Change Avatar
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">First Name</label>
                  <input type="text" defaultValue="Sarah" className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Last Name</label>
                  <input type="text" defaultValue="Connor" className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow" />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Email Address</label>
                  <input type="email" defaultValue="sarah.connor@studyhelper.edu" className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow" />
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-sm font-medium text-gray-700 dark:text-gray-300">Role</label>
                  <select className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-900 dark:text-white rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-shadow">
                    <option>Lead Administrator</option>
                    <option>Teacher</option>
                    <option>Counselor</option>
                    <option>Data Analyst</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Application Preferences */}
          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-200 dark:border-gray-700">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white">General Preferences</h2>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Customize how StudyHelper behaves for your account.</p>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white">Default Landing Page</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Choose which page to see when you first log in.</p>
                </div>
                <select className="px-3 py-1.5 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-sm text-gray-900 dark:text-white rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none">
                  <option>Dashboard</option>
                  <option>Students Directory</option>
                  <option>Predictive Analytics</option>
                </select>
              </div>

              <div className="border-t border-gray-100 dark:border-gray-700"></div>

              <div className="flex items-start justify-between">
                <div className="pr-4">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white">Daily Email Reports</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Receive a daily digest of high-risk student alerts and new model insights.</p>
                </div>
                <div className="flex items-center h-5 mt-1">
                  <input type="checkbox" defaultChecked className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500" />
                </div>
              </div>

              <div className="border-t border-gray-100 dark:border-gray-700"></div>

              <div className="flex items-start justify-between">
                <div className="pr-4">
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white">Strict Prediction Threshold</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Requires the AI model to have &gt;90% confidence before displaying a "High Risk" alert.</p>
                </div>
                <div className="flex items-center h-5 mt-1">
                  <input type="checkbox" className="w-4 h-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500" />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <button className="px-4 py-2 border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors shadow-sm">
              Cancel
            </button>
            <button 
              onClick={handleSave}
              disabled={saveStatus !== "idle"}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 transition-colors shadow-sm flex items-center gap-2 min-w-[120px] justify-center disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {saveStatus === "idle" && <><Save size={16} /> Save Changes</>}
              {saveStatus === "saving" && "Saving..."}
              {saveStatus === "saved" && "Saved!"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}