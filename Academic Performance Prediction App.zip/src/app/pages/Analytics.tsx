import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, PieChart, Pie, Cell } from "recharts";
import { BrainCircuit, Filter, Download } from "lucide-react";
import { riskDistribution } from "../data/mockData";

export function Analytics() {
  const cohortPerformance = [
    { grade: "9th", actual: 3.1, predicted: 3.0 },
    { grade: "10th", actual: 2.9, predicted: 3.1 },
    { grade: "11th", actual: 3.2, predicted: 3.3 },
    { grade: "12th", actual: 3.4, predicted: 3.5 },
  ];

  const modelAccuracyHistory = [
    { week: "W1", accuracy: 91 },
    { week: "W2", accuracy: 92 },
    { week: "W3", accuracy: 93 },
    { week: "W4", accuracy: 92.5 },
    { week: "W5", accuracy: 94 },
    { week: "W6", accuracy: 94.2 },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">Predictive Analytics</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">Macro trends and model performance metrics</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-700 shadow-sm transition-colors">
            <Filter size={16} /> Filter Data
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-indigo-600 border border-transparent rounded-lg text-sm font-medium text-white hover:bg-indigo-700 shadow-sm transition-colors">
            <Download size={16} /> Export CSV
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cohort Comparison */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Cohort Performance Prediction</h2>
            <select className="text-sm bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-200 rounded-md focus:ring-indigo-500 focus:border-indigo-500 py-1 pl-2 pr-8 outline-none">
              <option>By Grade</option>
              <option>By School</option>
            </select>
          </div>
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%" minHeight={300}>
              <BarChart data={cohortPerformance} margin={{ top: 20, right: 30, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#374151" strokeOpacity={0.2} />
                <XAxis dataKey="grade" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dy={10} />
                <YAxis domain={[2.0, 4.0]} axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} />
                <Tooltip 
                  cursor={{ fill: '#374151', opacity: 0.1 }}
                  contentStyle={{ borderRadius: '8px', border: '1px solid #374151', backgroundColor: '#1F2937', color: '#F3F4F6' }}
                />
                <Legend wrapperStyle={{ paddingTop: '20px', fontSize: '12px' }} />
                <Bar dataKey="actual" name="Current Avg GPA" fill="#9CA3AF" radius={[4, 4, 0, 0]} />
                <Bar dataKey="predicted" name="Predicted Next Term" fill="#4F46E5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Risk Distribution Pie */}
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 shadow-sm flex flex-col">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">School-wide Risk Distribution</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">Based on current model predictions for upcoming term</p>
          
          <div className="flex items-center justify-center min-h-[250px]">
            <ResponsiveContainer width="100%" height="100%" minHeight={250}>
              <PieChart>
                <Pie
                  data={riskDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  stroke="none"
                >
                  {riskDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: '1px solid #374151', backgroundColor: '#1F2937', color: '#F3F4F6' }}
                  itemStyle={{ fontWeight: 600, color: '#F3F4F6' }}
                />
              </PieChart>
            </ResponsiveContainer>
            
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className="text-3xl font-bold text-gray-900 dark:text-white">500</span>
              <span className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-widest mt-1">Total</span>
            </div>
          </div>
          
          <div className="flex justify-center gap-6 mt-4">
            {riskDistribution.map(item => (
              <div key={item.name} className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></span>
                <span className="text-sm text-gray-600 dark:text-gray-300 font-medium">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Model Accuracy Tracking */}
        <div className="lg:col-span-2 bg-gradient-to-br from-indigo-900 to-indigo-800 dark:from-indigo-950 dark:to-gray-900 border border-indigo-700 dark:border-gray-800 rounded-xl p-6 shadow-lg text-white">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-white/10 dark:bg-indigo-500/10 flex items-center justify-center backdrop-blur-sm border border-white/20 dark:border-indigo-500/20">
                <BrainCircuit size={24} className="text-indigo-200 dark:text-indigo-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold tracking-tight text-white">Model Accuracy Over Time</h2>
                <p className="text-indigo-200 dark:text-indigo-300 text-sm mt-1">Continuous learning tracking against actual outcomes</p>
              </div>
            </div>
            
            <div className="bg-white/10 dark:bg-gray-800/50 border border-white/20 dark:border-gray-700 rounded-lg py-2 px-4 backdrop-blur-sm text-center shrink-0">
              <p className="text-[10px] sm:text-xs text-indigo-200 dark:text-indigo-300 uppercase tracking-wider font-semibold">Current Accuracy</p>
              <p className="text-xl sm:text-2xl font-bold text-white mt-0.5">94.2%</p>
            </div>
          </div>
          
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%" minHeight={300}>
              <BarChart data={modelAccuracyHistory} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff20" />
                <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#C7D2FE' }} dy={10} />
                <YAxis domain={[80, 100]} axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#C7D2FE' }} />
                <Tooltip 
                  cursor={{ fill: '#ffffff10' }}
                  contentStyle={{ backgroundColor: '#1E1B4B', borderRadius: '8px', border: '1px solid #4338CA', color: 'white' }}
                  itemStyle={{ color: 'white', fontWeight: 'bold' }}
                />
                <Bar dataKey="accuracy" name="Accuracy %" fill="#818CF8" radius={[4, 4, 0, 0]} maxBarSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-6 pt-6 border-t border-white/10 dark:border-gray-800 flex items-center justify-between text-sm text-indigo-200 dark:text-gray-400">
            <p>Last training run: 2 days ago</p>
            <button className="text-white dark:text-indigo-400 font-medium hover:text-indigo-100 dark:hover:text-indigo-300 transition-colors flex items-center gap-1">
              View Model Parameters →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}