import { createBrowserRouter, redirect } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./pages/Dashboard";
import { StudentsList } from "./pages/StudentsList";
import { StudentDetail } from "./pages/StudentDetail";
import { Analytics } from "./pages/Analytics";
import { NewPrediction } from "./pages/NewPrediction";
import { Settings } from "./pages/Settings";
import { Login } from "./pages/Login";

const requireAuth = () => {
  const role = localStorage.getItem('userRole');
  if (!role) {
    return redirect("/login");
  }
  return null;
};

const requireTeacher = () => {
  const role = localStorage.getItem('userRole');
  if (!role) {
    return redirect("/login");
  }
  if (role === 'student') {
    return redirect("/students/STU-001");
  }
  return null;
};

export const router = createBrowserRouter([
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/",
    Component: Layout,
    loader: requireAuth,
    children: [
      { index: true, Component: Dashboard, loader: requireTeacher },
      { path: "students", Component: StudentsList, loader: requireTeacher },
      { path: "students/:id", Component: StudentDetail, loader: requireAuth },
      { path: "predict", Component: NewPrediction, loader: requireTeacher },
      { path: "analytics", Component: Analytics, loader: requireTeacher },
      { path: "settings", Component: Settings, loader: requireAuth },
      { path: "model", Component: () => <div className="p-8 text-center text-gray-500">Model Insights Page under construction. Visit Analytics for current model performance.</div>, loader: requireTeacher },
      { path: "*", Component: () => <div className="p-8 text-center text-gray-500">Page not found</div> },
    ],
  },
]);