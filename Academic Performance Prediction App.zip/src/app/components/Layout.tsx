import { NavLink, Outlet, useLocation, useNavigate } from "react-router";
import { LayoutDashboard, Users, Activity, Settings, BrainCircuit, Bell, Search, Menu, PlayCircle, Moon, Sun, LogOut } from "lucide-react";
import { useState, useEffect } from "react";

export function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  
  const userRole = localStorage.getItem('userRole') || 'teacher';
  const isStudent = userRole === 'student';

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };
  
  const handleLogout = () => {
    localStorage.removeItem('userRole');
    navigate('/login');
  };

  const teacherNavItems = [
    { to: "/", icon: LayoutDashboard, label: "Dashboard" },
    { to: "/students", icon: Users, label: "Students Directory" },
    { to: "/predict", icon: PlayCircle, label: "Run Prediction" },
    { to: "/analytics", icon: Activity, label: "Predictive Analytics" },
    { to: "/model", icon: BrainCircuit, label: "Model Insights" },
  ];

  const studentNavItems = [
    { to: "/students/STU-001", icon: Users, label: "My Profile" },
    { to: "/settings", icon: Settings, label: "Settings" },
  ];

  const navItems = isStudent ? studentNavItems : teacherNavItems;

  return (
    <div className={`flex h-screen ${isDarkMode ? 'bg-gray-900 text-gray-100' : 'bg-gray-50 text-gray-900'} font-sans overflow-hidden transition-colors duration-200`}>
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-gray-900/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} border-r transform transition-all duration-300 ease-in-out
        lg:relative lg:translate-x-0 flex flex-col
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
      `}>
        <div className={`p-6 flex items-center gap-3 border-b ${isDarkMode ? 'border-gray-800' : 'border-gray-100'}`}>
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
            <BrainCircuit size={20} />
          </div>
          <span className={`font-bold text-xl tracking-tight ${isDarkMode ? 'text-white' : 'text-gray-900'}`}>StudyHelper</span>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `
                flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors
                ${isActive 
                  ? (isDarkMode ? "bg-indigo-900/50 text-indigo-400" : "bg-indigo-50 text-indigo-700") 
                  : (isDarkMode ? "text-gray-400 hover:bg-gray-800 hover:text-gray-200" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900")}
              `}
              onClick={() => setSidebarOpen(false)}
            >
              <item.icon size={18} className={location.pathname === item.to ? (isDarkMode ? "text-indigo-400" : "text-indigo-600") : "text-gray-400"} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className={`p-4 border-t ${isDarkMode ? 'border-gray-800' : 'border-gray-100'} space-y-2`}>
          {!isStudent && (
            <NavLink 
              to="/settings"
              className={({ isActive }) => `flex items-center gap-3 px-3 py-2.5 w-full rounded-lg text-sm font-medium transition-colors ${
                isActive 
                  ? (isDarkMode ? "bg-indigo-900/50 text-indigo-400" : "bg-indigo-50 text-indigo-700") 
                  : (isDarkMode ? "text-gray-400 hover:bg-gray-800 hover:text-gray-200" : "text-gray-600 hover:bg-gray-50 hover:text-gray-900")
              }`}
              onClick={() => setSidebarOpen(false)}
            >
              <Settings size={18} />
              Settings
            </NavLink>
          )}
          <button 
            onClick={handleLogout}
            className={`flex items-center gap-3 px-3 py-2.5 w-full rounded-lg text-sm font-medium transition-colors ${isDarkMode ? 'text-red-400 hover:bg-red-900/20' : 'text-red-600 hover:bg-red-50'}`}
          >
            <LogOut size={18} />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <header className={`h-16 ${isDarkMode ? 'bg-gray-900 border-gray-800' : 'bg-white border-gray-200'} border-b flex items-center justify-between px-4 lg:px-8 shrink-0 transition-colors duration-200`}>
          <div className="flex items-center gap-4">
            <button 
              className={`lg:hidden p-2 -ml-2 rounded-md ${isDarkMode ? 'text-gray-400 hover:bg-gray-800' : 'text-gray-500 hover:bg-gray-100'}`}
              onClick={() => setSidebarOpen(true)}
            >
              <Menu size={20} />
            </button>
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input 
                type="text" 
                placeholder={isStudent ? "Search courses..." : "Search students, classes..."}
                className={`pl-9 pr-4 py-1.5 w-64 rounded-full border text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all ${isDarkMode ? 'bg-gray-800 border-gray-700 text-gray-200 focus:bg-gray-800' : 'bg-gray-50 border-gray-300 text-gray-900 focus:bg-white'}`}
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={toggleDarkMode}
              className={`p-2 rounded-full transition-colors ${isDarkMode ? 'text-gray-400 hover:bg-gray-800' : 'text-gray-500 hover:bg-gray-100'}`}
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <button className={`relative p-2 rounded-full transition-colors ${isDarkMode ? 'text-gray-400 hover:bg-gray-800' : 'text-gray-500 hover:bg-gray-100'}`}>
              <Bell size={20} />
              <span className={`absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border ${isDarkMode ? 'border-gray-900' : 'border-white'}`}></span>
            </button>
            <div className={`flex items-center gap-3 border-l pl-4 ${isDarkMode ? 'border-gray-800' : 'border-gray-200'}`}>
              {isStudent ? (
                <>
                  <img 
                    src="https://images.unsplash.com/photo-1599566150163-29194dcaad36?auto=format&fit=crop&q=80&w=100&h=100" 
                    alt="Student" 
                    className="w-8 h-8 rounded-full bg-gray-200 object-cover"
                  />
                  <div className="hidden md:block">
                    <p className={`text-sm font-medium ${isDarkMode ? 'text-gray-200' : 'text-gray-900'}`}>Alex Johnson</p>
                    <p className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>10th Grade</p>
                  </div>
                </>
              ) : (
                <>
                  <img 
                    src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100&h=100" 
                    alt="Teacher" 
                    className="w-8 h-8 rounded-full bg-gray-200 object-cover"
                  />
                  <div className="hidden md:block">
                    <p className={`text-sm font-medium ${isDarkMode ? 'text-gray-200' : 'text-gray-900'}`}>Dr. Sarah Connor</p>
                    <p className={`text-xs ${isDarkMode ? 'text-gray-500' : 'text-gray-500'}`}>Lead Administrator</p>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto p-4 lg:p-8">
          <div className="max-w-7xl mx-auto">
            <Outlet context={{ isDarkMode }} />
          </div>
        </main>
      </div>
    </div>
  );
}